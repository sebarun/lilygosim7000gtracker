#pragma once
void batteryInit();