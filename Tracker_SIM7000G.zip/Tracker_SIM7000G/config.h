
#pragma once
#define GSM_PIN "1336"
#define ADMIN "+34689669598"
#define APN_FI "fi.omv.es"
#define APN_PERSONAL "datos.personal.com"
#define BAT_LOW 20
